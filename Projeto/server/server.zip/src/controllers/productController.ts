// extrutura universal de controllers
import { Request, Response } from "express";
import { IProduct } from "../data/interfaces/interfaces.js";
import productService from "../services/productService.js";

class ProductController {
    getAll = async (req: Request, res: Response) => {
        try {
            const products: IProduct[] | undefined =
                await productService.getAll();
            res.json(products);
        } catch (error) {
            res.status(500).json({ error: "Failed to get products" });
        }
    };
    getOne = async (req: Request, res: Response) => {
        try {
            const productId: string = req.params.id;
            const product: IProduct | undefined =
                productService.getProductById(productId);
            if (!product) {
                res.status(404).json({ error: "Product not found" });
            }

            res.json(product);
        } catch (error) {
            res.status(500).json({ error: "Failed to get product" });
        }
    };
    create = async (req: Request, res: Response) => {
        try {
            const productToCreate: IProduct = req.body;
            const createdProduct: any = await productService.create(
                productToCreate
            );
            res.status(201).json(createdProduct);
        } catch (error) {
            res.status(500).json({ error: "Failed to create product" });
        }
    };
    update = async (req: Request, res: Response) => {
        try {
            const productId: string = req.params.id;
            const productToUpdate: IProduct = req.body;
            const updatedProduct: IProduct | undefined = productService.update(
                productId,
                productToUpdate
            );
            if (!updatedProduct) {
                res.status(404).json({ error: "Product not found" });
            }
            res.json(updatedProduct);
        } catch (error) {
            res.status(500).json({ error: "Failed to update product" });
        }
    };
    delete = (req: Request, res: Response) => {
        try {
            const productId: string = req.params.id;
            const deletedProduct: IProduct | undefined =
                productService.delete(productId);

            if (!deletedProduct) {
                res.status(404).json({ error: "Product not found" });
            }
            res.json(deletedProduct);
        } catch (error) {
            res.status(500).json({ error: "Failed to delete product" });
        }
    };
}

export default new ProductController();

// fim da extrutura universal de controllers
