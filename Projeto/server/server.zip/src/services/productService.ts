// extrutura universal de service
import { IProduct } from "../data/interfaces/interfaces.js";
import JsonFileReader from "../utils/jsonFileReader.js";
import { v4 as uuidv4 } from "uuid";

const productsJsonPath: string = "./src/data/products.json";

class ProductService {
    private readProductsJson(): IProduct[] | undefined {
        try {
            return JsonFileReader.read(productsJsonPath);
        } catch (error) {
            throw new Error("Failed to read products from file");
        }
    }

    private writeProductsJson(products: IProduct[]): void {
        try {
            JsonFileReader.write(productsJsonPath, products);
        } catch (error) {
            throw new Error("Failed to write products from file");
        }
    }

    getAll = (): IProduct[] | undefined => {
        try {
            return this.readProductsJson();
        } catch (error) {
            throw new Error("Failed to get all products");
        }
    };
    getProductById = (productId: string): IProduct | undefined => {
        try {
            const products: IProduct[] | undefined = this.readProductsJson();
            return products?.find(
                (product: IProduct) => product.id === productId
            );
        } catch (error) {
            throw new Error("Failed to get product by id");
        }
    };
    create = (newProduct: IProduct): IProduct => {
        try {
            const products: IProduct[] | undefined = this.readProductsJson();
            if (!products) {
                throw new Error("Failed to read product");
            }

            newProduct.id = uuidv4();
            products?.push(newProduct);

            this.writeProductsJson(products);
            return newProduct;
        } catch (error) {
            throw new Error("Failed to create product");
        }
    };
    update = (productId: string, product: IProduct): IProduct | undefined => {
        try {
            const products: IProduct[] | undefined = this.readProductsJson();
            if (!products) {
                throw new Error("Failed to read product");
            }
            const productIndex = products.findIndex(
                (product: IProduct) => product.id === productId
            );

            if (productIndex == -1) {
                return undefined;
            }
            const productToUpdateWithId = {
                ...products[productIndex],
                ...product,
            };
            products[productIndex] = productToUpdateWithId;
            this.writeProductsJson(products);
            return productToUpdateWithId;
        } catch (error) {
            throw new Error("Failed to update product");
        }
    };
    delete = (productId: string): IProduct | undefined => {
        try {
            const products: IProduct[] | undefined = this.readProductsJson();
            if (!products) {
                throw new Error("Failed to read product");
            }
            const productIndex = products.findIndex(
                (product: IProduct) => product.id === productId
            );

            if (productIndex === -1) {
                return undefined;
            }
            const deletedProduct = products.splice(productIndex, 1)[0];
            this.writeProductsJson(products);
            return deletedProduct;
        } catch (error) {
            throw new Error("Failed to delete product");
        }
    };
}

export default new ProductService();

// fim da extrutura universal de service
