import { Router } from "express";

import ProductController from "../controllers/productController.js";

const router: Router = Router();

// let users: IProduct[] = JSON.parse(
//     readFileSync("./src/data/products.json", "utf-8")
// ); //importar o ficheiro JSON dos products

//Get all products
router.get("/products", ProductController.getAll);

// Get products by id
router.get("/products/:id", ProductController.getOne);

// Create a new product
router.post("/products", ProductController.create);

// Update an existing product
router.put("/products/:id", ProductController.update);

// Delete and existing product

router.delete("/products/:id", ProductController.delete);

// //Search by name

// router.get("/products/name/:name", (req: Request, res: Response) => {});

// let products: IProduct[] = JSON.parse(
//     readFileSync("./src/data/products.json", "utf-8")
// ); //importar o ficheiro JSON dos products

export default router;
